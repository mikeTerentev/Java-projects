package javax.imageio;

public class IIOExceptionImpl extends IIOException {
    public IIOExceptionImpl(java.lang.String arg0) {
        super(arg0);
    }

    public IIOExceptionImpl(java.lang.String arg0, java.lang.Throwable arg1) {
        super(arg0, arg1);
    }

}
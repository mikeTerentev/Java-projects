package javax.management.remote.rmi;

public class RMIServerImplImpl extends RMIServerImpl {
    public RMIServerImplImpl(java.util.Map arg0) {
        super(arg0);
    }

    protected javax.management.remote.rmi.RMIConnection makeClient(java.lang.String arg0, javax.security.auth.Subject arg1) throws java.io.IOException {
        return null;
    }

    protected void closeServer() throws java.io.IOException {
        return;
    }

    public java.rmi.Remote toStub() throws java.io.IOException {
        return null;
    }

    protected void export() throws java.io.IOException {
        return;
    }

    protected void closeClient(javax.management.remote.rmi.RMIConnection arg0) throws java.io.IOException {
        return;
    }

    protected java.lang.String getProtocol() {
        return null;
    }

}
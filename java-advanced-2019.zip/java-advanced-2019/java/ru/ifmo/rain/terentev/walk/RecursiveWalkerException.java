package ru.ifmo.rain.terentev.walk;

import java.io.IOException;

class RecursiveWalkerException extends Exception {

    RecursiveWalkerException(String message) {
        super(message);
    }
}

package ex;

import java.util.*;

public class Ex {

    public static void main(String args[]) {
        Class<?> aClass = null;
        try {
            aClass = Class.forName("ru.ifmo.rain.terentev.students.StudentDB");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        List<Integer> list = new ArrayList<Integer>(Arrays.asList(116329891, 1990855908, -2067503026, 204245076, -1410053989, 487765060, -1858846132));
       // NavigableSet<Integer> arrayset = new ArraySet<>(list);
       // int res = arrayset.lower(116329891);
       // System.out.println(res);
        System.out.println(~(-1));
    }
}
//-1303189030      -682028319
//-772057278       -556322390
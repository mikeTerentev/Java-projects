package info.kgeorgiy.java.advanced.implementor.standard.full;

public class SDeprecatedImpl implements SDeprecated {
    public java.lang.Class annotationType() {
        return null;
    }

    public java.lang.String toString() {
        return null;
    }

    public java.lang.String since() {
        return null;
    }

    public boolean forRemoval() {
        return false;
    }

    public int hashCode() {
        return 0;
    }

    public boolean equals(java.lang.Object arg0) {
        return false;
    }

}
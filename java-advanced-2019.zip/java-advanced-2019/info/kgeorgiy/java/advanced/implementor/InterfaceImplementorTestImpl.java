package info.kgeorgiy.java.advanced.implementor;

public class InterfaceImplementorTestImpl extends InterfaceImplementorTest {
    public InterfaceImplementorTestImpl() {
        super();
    }

}
package info.kgeorgiy.java.advanced.implementor.basic.interfaces;

public class InterfaceWithDefaultMethodImpl implements InterfaceWithDefaultMethod {
    public int hello() {
        return 0;
    }

}
package info.kgeorgiy.java.advanced.student;

public class StudentQueryImpl implements StudentQuery {
    public java.util.List getGroups(java.util.List arg0) {
        return null;
    }

    public java.util.List getFirstNames(java.util.List arg0) {
        return null;
    }

    public java.util.List getLastNames(java.util.List arg0) {
        return null;
    }

    public java.util.List getFullNames(java.util.List arg0) {
        return null;
    }

    public java.util.Set getDistinctFirstNames(java.util.List arg0) {
        return null;
    }

    public java.lang.String getMinStudentFirstName(java.util.List arg0) {
        return null;
    }

    public java.util.List sortStudentsById(java.util.Collection arg0) {
        return null;
    }

    public java.util.List sortStudentsByName(java.util.Collection arg0) {
        return null;
    }

    public java.util.List findStudentsByFirstName(java.util.Collection arg0, java.lang.String arg1) {
        return null;
    }

    public java.util.List findStudentsByLastName(java.util.Collection arg0, java.lang.String arg1) {
        return null;
    }

    public java.util.List findStudentsByGroup(java.util.Collection arg0, java.lang.String arg1) {
        return null;
    }

    public java.util.Map findStudentNamesByGroup(java.util.Collection arg0, java.lang.String arg1) {
        return null;
    }

    public java.util.List findStudentNamesByGroupList(java.util.List arg0, java.lang.String arg1) {
        return null;
    }

}
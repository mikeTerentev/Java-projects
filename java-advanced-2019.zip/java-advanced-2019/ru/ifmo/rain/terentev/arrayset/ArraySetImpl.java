package ru.ifmo.rain.terentev.arrayset;

public class ArraySetImpl extends ArraySet {
    public ArraySetImpl(Collection arg0Comparator arg1) {
        super(CollectionComparator);
    }

    public ArraySetImpl(Collection arg0) {
        super(Collection);
    }

    public ArraySetImpl() {
        super();
    }


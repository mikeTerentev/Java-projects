module ru.ifmo.rain.terentev.implementor {
    requires transitive info.kgeorgiy.java.advanced.implementor;
    requires java.compiler;
}
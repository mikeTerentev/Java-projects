package info.kgeorgiy.java.advanced.implementor.full.interfaces;

import java.util.RandomAccess;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public interface InterfaceWithoutMethods extends RandomAccess {
}

package info.kgeorgiy.java.advanced.implementor.basic.interfaces.standard;

/**
 * Copy of {@link java.util.RandomAccess}
 */
public interface RandomAccess {
}

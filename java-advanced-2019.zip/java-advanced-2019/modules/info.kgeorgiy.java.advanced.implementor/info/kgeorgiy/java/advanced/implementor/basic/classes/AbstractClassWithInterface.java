package info.kgeorgiy.java.advanced.implementor.basic.classes;

import java.io.DataInput;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public abstract class AbstractClassWithInterface implements DataInput {
}

package info.kgeorgiy.java.advanced.implementor.full.lang;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public abstract class Russian implements \u041f\u0440\u0438\u0432\u0435\u0442Interface {
    public Russian(\u041f\u0440\u0438\u0432\u0435\u0442 \u043f\u0440\u0438\u0432\u0435\u0442) throws \u041f\u0440\u0438\u0432\u0435\u0442 {
    }

    public abstract \u041f\u0440\u0438\u0432\u0435\u0442 \u043f\u0440\u0438\u0432\u0435\u0442(\u041f\u0440\u0438\u0432\u0435\u0442 \u043f\u0440\u0438\u0432\u0435\u0442) throws \u041f\u0440\u0438\u0432\u0435\u0442;
}

class \u041f\u0440\u0438\u0432\u0435\u0442 extends Exception {
}

package info.kgeorgiy.java.advanced.implementor.full.lang;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public abstract class Greek {
    public Greek(\u03b3\u03b5\u03b9\u03b1 \u03b3\u03b5\u03b9\u03b1) throws \u03b3\u03b5\u03b9\u03b1 {
    }

    public abstract \u03b3\u03b5\u03b9\u03b1 \u03b3\u03b5\u03b9\u03b1(\u03b3\u03b5\u03b9\u03b1 \u03b3\u03b5\u03b9\u03b1) throws \u03b3\u03b5\u03b9\u03b1;
}

class \u03b3\u03b5\u03b9\u03b1 extends Exception {
}

package info.kgeorgiy.java.advanced.implementor.full.lang;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public abstract class Arabic {
    public Arabic(\u0645\u0631\u062d\u0628\u0627 \u0645\u0631\u062d\u0628\u0627) throws \u0645\u0631\u062d\u0628\u0627 {
    }

    public abstract \u0645\u0631\u062d\u0628\u0627 \u0645\u0631\u062d\u0628\u0627(\u0645\u0631\u062d\u0628\u0627 \u0645\u0631\u062d\u0628\u0627) throws \u0645\u0631\u062d\u0628\u0627;
}

class \u0645\u0631\u062d\u0628\u0627 extends Exception {
}

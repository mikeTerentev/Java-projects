package info.kgeorgiy.java.advanced.implementor.full.lang;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public abstract class Hebrew {
    public Hebrew(\u05d4\u05d9 \u05d4\u05d9) throws \u05d4\u05d9 {
    }

    public abstract \u05d4\u05d9 \u05d4\u05d9(\u05d4\u05d9 \u05d4\u05d9) throws \u05d4\u05d9;
}

class \u05d4\u05d9 extends Exception {
}

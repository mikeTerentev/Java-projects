package info.kgeorgiy.java.advanced.implementor.full.lang;

public interface \u041f\u0440\u0438\u0432\u0435\u0442Interface {
}

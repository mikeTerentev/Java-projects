
javadoc \
    -html4 \
    -link https://docs.oracle.com/en/java/javase/11/docs/api/ \
    -private \
    -d ./../javaDocJarImplementor \
     ../java/ru/ifmo/rain/terentev/implementor/Implementor.java \
     ../java/ru/ifmo/rain/terentev/implementor/package-info.java \
     ../modules/info.kgeorgiy.java.advanced.implementor/info/kgeorgiy/java/advanced/implementor/Impler.java \
     ../modules/info.kgeorgiy.java.advanced.implementor/info/kgeorgiy/java/advanced/implementor/JarImpler.java \
     ../modules/info.kgeorgiy.java.advanced.implementor/info/kgeorgiy/java/advanced/implementor/ImplerException.java